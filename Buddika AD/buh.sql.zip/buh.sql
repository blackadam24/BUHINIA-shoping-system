-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2022 at 01:42 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buh`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `adname` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `addres` varchar(80) NOT NULL,
  `passwrd` varchar(35) NOT NULL,
  `utype` varchar(40) NOT NULL,
  `mobile` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `adname`, `email`, `addres`, `passwrd`, `utype`, `mobile`) VALUES
(1, 'supun', 'supun@gmail.com', 'matara', 'supun123', 'handling clerk', '0702756743'),
(2, 'nuwan', 'nuwan@gmail.com', 'matara', 'nuwan123', 'production manager', '0702756743'),
(3, 'madawa', 'madawa@gmail.com', 'matara', 'madawa123', 'chief accountant', '0754433241');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderid` int(255) NOT NULL,
  `usrname` varchar(70) NOT NULL,
  `email` varchar(80) NOT NULL,
  `delivaddress` varchar(70) NOT NULL,
  `mobile1` varchar(11) NOT NULL,
  `mobile2` varchar(11) NOT NULL,
  `price` int(255) NOT NULL,
  `currentdate` date NOT NULL,
  `placedorder` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderid`, `usrname`, `email`, `delivaddress`, `mobile1`, `mobile2`, `price`, `currentdate`, `placedorder`) VALUES
(1, 'ajith', 'ajith@gmail.com', 'nupe', '0765855456', '0761232367', 3000, '2022-01-15', 'requested'),
(2, 'saman', 'saman@gmail.com', 'polhena', '0712342125', '0728932102', 5000, '2022-01-15', 'requested');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(11) NOT NULL,
  `name` varchar(70) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(255) NOT NULL,
  `category` varchar(50) NOT NULL,
  `quantity` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `name`, `image`, `price`, `category`, `quantity`) VALUES
(3, 'Legendary Whitetails Men\'s Buck Camp Flannel Shirt', 'shirt3.jpg', 4000, 'tshirts', 40),
(4, 'Legendary Whitetails Men\'s Shotgun Western Flannel Shirt', 'shirt2.jpg', 3500, 'tshirts', 20),
(5, 'Fit Long Sleeve Plaid Flannel Casual Shirts', 'shirt1.jpg', 6000, 'tshirts', 30);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(255) NOT NULL,
  `uname` varchar(70) NOT NULL,
  `email` varchar(80) NOT NULL,
  `addres` varchar(120) NOT NULL,
  `passw` varchar(70) NOT NULL,
  `mobile1` varchar(11) NOT NULL,
  `mobile2` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderid`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `orderid` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
